import React from 'react';

const FooterComponent = () => (
<div className="ui inverted vertical footer segment form-page">
  <div className="ui container">
   <p>Copyright © 2018. YASH Technologies. All Rights Reserved. </p>
  </div>
</div>
)
export default FooterComponent;