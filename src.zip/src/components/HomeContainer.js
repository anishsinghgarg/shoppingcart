import React from 'react'
import { Container, Header } from 'semantic-ui-react';
import 'semantic-ui-css/semantic.min.css';

const HomeContainer = () => (
     <div class="image">
    <img src='shopping-cart.jpg' className='ui fluid image'></img>
    </div>
)
export default HomeContainer