export const ADD_USER = 'ADD_USER';
export const DELETE_USER = 'DELETE_POST';
export const FETCH_USER = 'FETCH_USER';
export const UPDATE_USER = 'UPDATE_USER';